#puts "Hello World!"
#puts "Hello Again"
#puts "I like typing this.
#=begin
puts "This is fun."
puts "Yay! Printing."
puts "I'd much rather you 'not'."
#=end
puts 'I "said" do not touch this.'
