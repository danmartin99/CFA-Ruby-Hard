first, second, third = ARGV

puts "Your first variable is: #{first}"
puts "Your second variable is: #{second}"
puts "Your third variable is: #{third}"

#four = gets.chomp

#puts "4th variable is #{four}"

five = $stdin.gets.chomp

puts "5th variable is #{five}"
