print "How old are you "
age = gets.chomp.to_i

print "How tall are you "
height = gets.chomp

print "How much do you weigh "
weight = gets.chomp

puts "So your #{age / 2} years old, #{height} tall and weigh #{weight}."
