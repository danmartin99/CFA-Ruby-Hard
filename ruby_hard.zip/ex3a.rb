# Does the 30 / 6 divide 1st (30 / 6 = 5 25 + 5 = 30)

puts "Hens #{25.00 + 30.00 / 6.00}"
# 25 * 3 = 75, 75 % 4 is remainer 15 remainder 3, it uses the 3 100 - 3 =97

puts "Roosters #{100.00 - 25.00 * 3.00 % 4.00}"

puts "Now I will count the eggs:"
# this ones on the to hard list
puts 3.00 + 2.00 + 1.00 - 5.00 + 4.00 % 2.00 - 1.00 / 4.00 + 6.00

puts "Is it true that 3 + 2 < 5 - 7?"
# it is true that 5 is GT 2
puts 3.00 + 2.00 < 5.00 - 7.00
# yep 5
puts "What is 3 + 2? #{3.00 + 2.00}"
# yep - 2
puts "What is 5 - 7? #{5.00 - 7.00}"
# yep
puts "Oh, that's why it's false."

puts "How about some more."
# yes this is true
puts "Is it greater? #{5.00 > -2.00}"
# so is this
puts "Is it greater or equal? #{5.00 >= -2.00}"
# thsi is false 5 is not less that or = 2
puts "Is it less or equal? #{5.00 <= -2.00}"
